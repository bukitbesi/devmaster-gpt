# AGENTS.md — DevMaster-GPT Agent Guide

## 🧠 Project Context
Devmaster-GPT is a hybrid AI agent platform designed to enhance software development through prompt-driven automation, memory-based tools, and seamless repo awareness. It uses Codex and GPT-4-based tools to generate, refactor, and document code with precision.

## 📁 Repo Structure Summary
- `/backend/`: Express app, auth, routing, and memory logic
- `/tools/`: Modular utilities like `generate_snippet`, `refactor_code`, `repo_structure`
- `/cli/`: CLI interfaces for local dev
- `main.py`, `app.py`: Entrypoints for Python-based flow (FastAPI)
- `requirements.txt`: Python dependencies
- `package.json`: Node.js dependencies
- `.env.example`: Safe reference for env variables

## ✅ Codex Goals
- Avoid full-file diffs; propose patch-based updates only
- Use `repo_structure()` before multi-file reasoning
- Call `set_project_goal()` and `recall_goal()` to maintain context
- Use FastAPI `/chain` endpoint for generate → refactor → doc workflow
- Focus edits only on modular tools, unless explicitly asked to modify core

## 🧪 Testing
- JS: Run `npm run lint && npm test`
- Python: Run `pytest`
- API: Use Postman or curl to hit `/chain`, `/generate`, `/doc`

## 🔐 Security Rules
- Do not modify `.env` or expose secrets
- Respect `.gitignore`, ESLint and Black formatting
- Avoid auth, login, session edits unless prompted

## 🔍 Codex Tips
- Think in micro-updates, not full rewrites
- Ask before restructuring large logic blocks
- Use clear commit messages per change (e.g., fix: optimize prompt parser)
