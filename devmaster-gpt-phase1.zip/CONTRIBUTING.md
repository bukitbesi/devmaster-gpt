# CONTRIBUTING.md

## 📦 How to Contribute

Thank you for contributing to `devmaster-gpt`! This project is powered by AI + Human synergy. Here’s how to keep things clean and useful:

### ⚙️ Setup
- Install Python 3.10+, Node.js 16+, and latest pip
- Run `npm install` in `/backend`
- Run `pip install -r requirements.txt` in root

### 🧠 Best Practices
- Use modular tools (`/tools`) for all new features
- Test before PR with: `npm test` and `pytest`
- Use consistent commit messages: `feat:`, `fix:`, `refactor:`

### 🔄 Branching
- Use feature branches: `feature/xyz`
- Submit PRs to `main` (protected)
- Link issues in PRs if applicable

### 🤖 Codex Users
- Please ensure Codex reads `AGENTS.md` before acting
- Avoid full file diffs; suggest only block-level edits

