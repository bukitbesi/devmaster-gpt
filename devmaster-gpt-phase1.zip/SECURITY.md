# SECURITY.md

## 🔐 Security Policy

### Supported Versions
We only maintain the `main` branch.

### 📢 Reporting a Vulnerability
To report a security issue, please email **security@devmaster.ai**.

### ✅ Best Practices
- Never commit real API keys or `.env` values
- Use `.env.example` as reference only
- Run code in isolated environment
- Rotate tokens regularly
